package com.example.card29

import kotlin.random.Random

enum class Suit { HEARTS, DIAMONDS, CLUBS, SPADES }
enum class Rank(val display: String) {
    SEVEN("7"), EIGHT("8"), NINE("9"), TEN("10"), JACK("J"), QUEEN("Q"), KING("K"), ACE("A")
}
data class Card(val suit: Suit, val rank: Rank) { override fun toString(): String = "${'$'}{rank.display} of ${'$'}{suit.name}" }
data class Player(val id: String, val name: String, val isHuman: Boolean = false, var hand: MutableList<Card> = mutableListOf(), var score: Int = 0, var teamId: Int = -1)
data class Trick(val plays: MutableList<Pair<String, Card>> = mutableListOf())
data class GameState(val players: List<Player>, var dealerIndex: Int = 0, var currentPlayerIndex: Int = 0, var trump: Suit? = null, var trickHistory: MutableList<Trick> = mutableListOf(), var roundNumber: Int = 0, var isBiddingOpen: Boolean = true, var highestBid: Int = 0, var highestBidderId: String? = null, var kitty: List<Card> = listOf())

fun createStandard32Deck(): MutableList<Card> {
    val deck = mutableListOf<Card>()
    for (s in Suit.values()) for (r in Rank.values()) deck += Card(s, r)
    return deck
}

enum class AIDifficulty { EASY, MEDIUM, HARD }

class GameController(humanPlayerName: String = "You", private val aiDifficulty: AIDifficulty = AIDifficulty.MEDIUM) {
    companion object { const val PLAYER_COUNT = 6 }

    private val players: MutableList<Player> = MutableList(PLAYER_COUNT) { i ->
        val isHuman = (i == 0)
        Player(id = "P${'$'}i", name = if (isHuman) humanPlayerName else "Bot${'$'}i", isHuman = isHuman)
    }

    init { players.forEachIndexed { i, p -> p.teamId = i % 3 } }

    var state = GameState(players = players)

    var onDealComplete: ((GameState) -> Unit)? = null
    var onBiddingUpdate: ((GameState) -> Unit)? = null
    var onTrickPlayed: ((Trick, GameState) -> Unit)? = null
    var onRoundComplete: ((GameState) -> Unit)? = null
    var onMoveRequired: ((Player, GameState) -> Unit)? = null

    fun startNewGame() {
        players.forEach { it.hand.clear(); it.score = 0 }
        state = GameState(players = players)
        deal()
    }

    fun deal() {
        val deck = createStandard32Deck()
        deck.shuffle(Random(System.currentTimeMillis()))
        players.forEach { it.hand.clear() }
        for (i in 0 until 5) { for (p in players) p.hand.add(deck.removeAt(0)) }
        state.kitty = deck.toList()
        state.dealerIndex = state.roundNumber % PLAYER_COUNT
        state.currentPlayerIndex = (state.dealerIndex + 1) % PLAYER_COUNT
        state.roundNumber += 1
        state.isBiddingOpen = true
        state.highestBid = 0
        state.highestBidderId = null
        state.trump = null
        state.trickHistory.clear()
        players.forEach { it.hand.shuffle() }
        onDealComplete?.invoke(state)
        requestNextBid()
    }

    private var biddingOrder: List<Player> = listOf()
    private fun requestNextBid() {
        biddingOrder = (0 until PLAYER_COUNT).map { idx -> players[(state.currentPlayerIndex + idx) % PLAYER_COUNT] }
        biddingRound(0)
    }

    private fun biddingRound(index: Int) {
        if (index >= biddingOrder.size) {
            state.isBiddingOpen = false
            if (state.highestBidderId == null) {
                state.highestBid = 14
                state.highestBidderId = players[state.currentPlayerIndex].id
            }
            val bidder = players.first { it.id == state.highestBidderId }
            if (bidder.isHuman) {
                onBiddingUpdate?.invoke(state)
            } else {
                val chosenTrump = botChooseTrump(bidder)
                closeBiddingAndSetTrump(chosenTrump, bidder.id)
            }
            return
        }
        val p = biddingOrder[index]
        if (p.isHuman) {
            onBiddingUpdate?.invoke(state)
            onMoveRequired?.invoke(p, state)
        } else {
            val bid = botMakeBid(p)
            if (bid > 0) placeBid(p.id, bid)
            biddingRound(index + 1)
        }
    }

    fun placeBid(playerId: String, bid: Int): Boolean {
        if (!state.isBiddingOpen) return false
        val playerIndex = players.indexOfFirst { it.id == playerId }
        if (playerIndex == -1) return false
        if (bid <= state.highestBid) return false
        state.highestBid = bid
        state.highestBidderId = playerId
        onBiddingUpdate?.invoke(state)
        return true
    }

    fun passBid(playerId: String) {
        val nextIdx = (biddingOrder.indexOfFirst { it.id == playerId } + 1)
        biddingRound(nextIdx)
    }

    fun closeBiddingAndSetTrump(trump: Suit, bidderId: String) {
        state.isBiddingOpen = false
        state.trump = trump
        state.currentPlayerIndex = players.indexOfFirst { it.id == bidderId }
        onBiddingUpdate?.invoke(state)
        onMoveRequired?.invoke(players[state.currentPlayerIndex], state)
    }

    fun playCard(playerId: String, card: Card): Boolean {
        val p = players.find { it.id == playerId } ?: return false
        if (!p.hand.contains(card)) return false
        if (players[state.currentPlayerIndex].id != playerId) return false
        if (state.trickHistory.isEmpty() || state.trickHistory.last().plays.size >= PLAYER_COUNT) state.trickHistory.add(Trick())
        state.trickHistory.last().plays.add(playerId to card)
        p.hand.remove(card)
        onTrickPlayed?.invoke(state.trickHistory.last(), state)
        state.currentPlayerIndex = (state.currentPlayerIndex + 1) % PLAYER_COUNT
        if (state.trickHistory.last().plays.size == PLAYER_COUNT) {
            evaluateTrick(state.trickHistory.last())
            if (players.any { it.hand.isNotEmpty() }) {
                onMoveRequired?.invoke(players[state.currentPlayerIndex], state)
                if (!players[state.currentPlayerIndex].isHuman) botAutoPlay()
            } else {
                onRoundComplete?.invoke(state)
            }
        } else {
            val next = players[state.currentPlayerIndex]
            if (!next.isHuman) botAutoPlay()
            else onMoveRequired?.invoke(next, state)
        }
        return true
    }

    private fun evaluateTrick(trick: Trick) {
        val plays = trick.plays
        if (plays.isEmpty()) return
        val leadCard = plays[0].second
        val leadSuit = leadCard.suit
        var bestIdx = 0
        var bestCard = leadCard
        fun cardScore(c: Card): Int {
            val base = when (c.rank) {
                Rank.JACK -> 100
                Rank.NINE -> 90
                Rank.ACE -> 80
                Rank.TEN -> 70
                Rank.KING -> 60
                Rank.QUEEN -> 50
                Rank.EIGHT -> 40
                Rank.SEVEN -> 30
            }
            return when {
                c.suit == state.trump -> base + 1000
                c.suit == leadSuit -> base + 100
                else -> base
            }
        }
        var bestScore = cardScore(bestCard)
        for (i in 1 until plays.size) {
            val c = plays[i].second
            val s = cardScore(c)
            if (s > bestScore) {
                bestScore = s
                bestCard = c
                bestIdx = i
            }
        }
        val winnerId = plays[bestIdx].first
        val winner = players.first { it.id == winnerId }
        val trickPoint = plays.sumOf { pair -> cardPointValue(pair.second) }
        winner.score += trickPoint
        val winnerIndex = players.indexOfFirst { it.id == winnerId }
        state.currentPlayerIndex = winnerIndex
    }

    private fun cardPointValue(card: Card): Int {
        return when (card.rank) {
            Rank.ACE -> 3
            Rank.TEN -> 2
            Rank.KING -> 1
            else -> 0
        }
    }

    private fun botMakeBid(bot: Player): Int {
        val highCards = bot.hand.count { it.rank == Rank.JACK || it.rank == Rank.NINE || it.rank == Rank.ACE || it.rank == Rank.TEN }
        val estimated = 10 + highCards
        return when (aiDifficulty) {
            AIDifficulty.EASY -> if (estimated >= 13) estimated else 0
            AIDifficulty.MEDIUM -> if (estimated >= 12) estimated else 0
            AIDifficulty.HARD -> if (estimated >= 11) estimated else 0
        }
    }

    private fun botChooseTrump(bot: Player): Suit {
        val suitScores = mutableMapOf<Suit, Int>()
        for (s in Suit.values()) suitScores[s] = 0
        for (c in bot.hand) {
            val v = when (c.rank) {
                Rank.JACK -> 5
                Rank.NINE -> 4
                Rank.ACE -> 3
                Rank.TEN -> 2
                Rank.KING -> 1
                else -> 0
            }
            suitScores[c.suit] = suitScores.getValue(c.suit) + v
        }
        return suitScores.maxByOrNull { it.value }?.key ?: Suit.HEARTS
    }

    private fun botAutoPlay() {
        val bot = players[state.currentPlayerIndex]
        if (bot.isHuman) return
        if (state.trickHistory.isEmpty() || state.trickHistory.last().plays.size >= PLAYER_COUNT) {
            val leadCard = botLeadChoose(bot)
            playCard(bot.id, leadCard)
            return
        }
        val leadSuit = state.trickHistory.last().plays.first().second.suit
        val followCards = bot.hand.filter { it.suit == leadSuit }
        val chosen = if (followCards.isNotEmpty()) followCards.minByOrNull { rankOrderValue(it) }!! else bot.hand.minByOrNull { rankOrderValue(it) }!!
        playCard(bot.id, chosen)
    }

    private fun botLeadChoose(bot: Player): Card {
        return when (aiDifficulty) {
            AIDifficulty.EASY -> bot.hand.random()
            AIDifficulty.MEDIUM -> bot.hand.maxByOrNull { rankOrderValue(it) + (if (it.suit == state.trump) 20 else 0) }!!
            AIDifficulty.HARD -> {
                val trumps = bot.hand.filter { it.suit == state.trump }
                if (trumps.isNotEmpty()) trumps.maxByOrNull { rankOrderValue(it) }!! else bot.hand.maxByOrNull { rankOrderValue(it) }!!
            }
        }
    }
    private fun rankOrderValue(c: Card): Int {
        return when (c.rank) {
            Rank.JACK -> 100
            Rank.NINE -> 90
            Rank.ACE -> 80
            Rank.TEN -> 70
            Rank.KING -> 60
            Rank.QUEEN -> 50
            Rank.EIGHT -> 40
            Rank.SEVEN -> 30
        }
    }

    fun humanPlaceBid(bid: Int) { placeBid(players[0].id, bid); biddingRoundContinueAfterHuman() }
    fun humanPassBid() { passBid(players[0].id) }

    private var biddingOrder: List<Player> = listOf()
    private fun biddingRoundContinueAfterHuman() {
        val pos = biddingOrder.indexOfFirst { it.id == players[0].id }
        biddingRound(pos + 1)
    }

    fun humanPlayCard(card: Card) { playCard(players[0].id, card) }

    fun snapshotForUI(): Map<String, Any> {
        return mapOf(
            "players" to players.map { mapOf("id" to it.id, "name" to it.name, "isHuman" to it.isHuman, "handSize" to it.hand.size, "score" to it.score) },
            "humanHand" to players.first { it.isHuman }.hand.map { it.toString() },
            "trump" to state.trump?.name,
            "currentPlayerIndex" to state.currentPlayerIndex,
            "highestBid" to state.highestBid,
            "highestBidderId" to state.highestBidderId,
            "kittySize" to state.kitty.size
        )
    }
}
