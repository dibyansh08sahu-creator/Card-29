package com.example.card29

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    lateinit var controller: GameController
    lateinit var statusView: TextView
    lateinit var difficultySpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24,24,24,24)
        }

        statusView = TextView(this)
        root.addView(statusView, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        difficultySpinner = Spinner(this)
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, listOf("EASY","MEDIUM","HARD"))
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        difficultySpinner.adapter = adapter
        root.addView(difficultySpinner)

        val btnStart = Button(this).apply { text = "Start New Game (Offline: You vs 5 Bots)" }
        root.addView(btnStart, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        val scroll = ScrollView(this)
        val logView = TextView(this)
        scroll.addView(logView)
        root.addView(scroll, LinearLayout.LayoutParams.MATCH_PARENT, 800)

        setContentView(root)

        // default medium
        controller = GameController(humanPlayerName = "You", aiDifficulty = AIDifficulty.MEDIUM)

        controller.onDealComplete = { state ->
            runOnUiThread {
                val humanHand = state.players.first { it.isHuman }.hand
                val h = humanHand.joinToString(", ") { it.toString() }
                statusView.text = "Your hand: $h\nTrump: ${'$'}{state.trump ?: "(not set)"}\nBid: ${'$'}{state.highestBid}"
                logView.append("Dealt. Your hand: $h\n\n")
                Toast.makeText(this, "Dealt. Check log for your hand.", Toast.LENGTH_SHORT).show()
            }
        }

        controller.onBiddingUpdate = { state ->
            runOnUiThread {
                logView.append("Bidding updated. Highest bid: ${'$'}{state.highestBid} by ${'$'}{state.highestBidderId}\n")
            }
        }

        controller.onTrickPlayed = { trick, state ->
            runOnUiThread {
                logView.append("Trick: ${'$'}{trick.plays.joinToString { "${'$'}{it.first}:${'$'}{it.second}" }}\n")
            }
        }

        controller.onRoundComplete = { state ->
            runOnUiThread {
                val scores = state.players.joinToString { "${'$'}{it.name}:${'$'}{it.score}" }
                logView.append("Round complete. Scores: $scores\n\n")
                Toast.makeText(this, "Round complete. See log.", Toast.LENGTH_SHORT).show()
            }
        }

        btnStart.setOnClickListener {
            val diffStr = difficultySpinner.selectedItem as String
            val diff = when(diffStr) {
                "EASY" -> AIDifficulty.EASY
                "HARD" -> AIDifficulty.HARD
                else -> AIDifficulty.MEDIUM
            }
            controller = GameController(humanPlayerName = "You", aiDifficulty = diff)
            controller.onDealComplete = { state ->
                runOnUiThread {
                    val humanHand = state.players.first { it.isHuman }.hand
                    val h = humanHand.joinToString(", ") { it.toString() }
                    statusView.text = "Your hand: $h\nTrump: ${'$'}{state.trump ?: "(not set)"}\nBid: ${'$'}{state.highestBid}"
                    logView.append("Dealt. Your hand: $h\n\n")
                }
            }
            controller.onBiddingUpdate = { state -> runOnUiThread { logView.append("Bidding updated. Highest bid: ${'$'}{state.highestBid} by ${'$'}{state.highestBidderId}\n") } }
            controller.onTrickPlayed = { trick, state -> runOnUiThread { logView.append("Trick: ${'$'}{trick.plays.joinToString { "${'$'}{it.first}:${'$'}{it.second}" }}\n") } }
            controller.onRoundComplete = { state -> runOnUiThread { val scores = state.players.joinToString { "${'$'}{it.name}:${'$'}{it.score}" }; logView.append("Round complete. Scores: $scores\n\n") } }
            controller.startNewGame()
        }
    }
}
